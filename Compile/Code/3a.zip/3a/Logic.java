/*
 * Class Logic
 * @author Jacqueline
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase logica, en la cual se instancian y 
 * ejecutan todas las clases del programa 3a.
 *
 * @version 1.0 15 Junio 2022
 * @author Jacqueline Castillo
 */

public class Logic {

    //private String dataX;
    //private String dataY;
    //private String dataXk;
    //private String arrDataX;
    //private String arrDataY;
    //public String arrDataXk;
    //public double thisXk;

    private String data;
    private String[] arrData;
    private String[] estimacion;
    private int n;

   
    /**
     * Default constructor
     */
    public Logic() {
    }

    /**
     * @return
     */
    public void logic3a() {

        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		EstimacionCorLineal myEsCoLi = new EstimacionCorLineal();

        data = myInput.readData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 3a\\Code\\test4.txt");

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("****************************************");
        System.out.println("n : " + n);

        estimacion = myEsCoLi.Estimacion(arrData, n);

        System.out.println("****************************************");

        myOut.writeData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 3a\\Code\\out4.txt", "SumX = " + estimacion[0] + "\nSumY = " + estimacion[1] + "\nSumXX = " + estimacion[2] + "\nSumXY = " + estimacion[3] + "\nSumYY = " + estimacion[4] + "\nAvgX = " + estimacion[5] + "\nAvgY = " + estimacion[6] + "\nB1 = " + estimacion[7] + "\nB0 = " + estimacion[8] + "\nRxy = " + estimacion[9] + "\nYK = " + estimacion[10] + "\nR = " + estimacion[11]);
    }

}